/**
 * Created by areynolds on 8/12/2015.
 */


Facade.Behaviors.Page.forPage("SurveyReview").onLoad( function(behaviorfn,args){});
Facade.Behaviors.Page.forPage("SurveyReview").onDestroy(function(behaviorFn,args){
    var data = Facade.PageRegistry.getPrimaryData();
    data.resetClean();
});

// show if questionText is A
Facade.Components.Field.forName("radioSetField").setMask(function(behaviorFn, args) {
    var questionText = this.getPathData().get('questionType');
    if (questionText === "BOOL" || questionText == "CHOICE" ){//||//questionText == "SELECT") {
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

Facade.Components.Radio.forKind('radiobtn').setMask(function(behaviorFn,args){
    var opts = this.getPathData().get('answerOptions').getRaw();
    var questionText = this.getPathData().get('questionType');
    var index = this.getValue().getRaw();
    if(questionText == 'BOOL'){
        if( index < 2 ){
            return Facade.Constants.Mask.NORMAL;
        }
    }

    if( opts[index] ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;

});

Facade.FunctionRegistry.register("page.radiobtn.setLabel",function(behaviorFn,args){
    var label = this.getPathData().get('answerOptions').getRaw();
    var questionText = this.getPathData().get('questionType');
    var index = this.getValue().getRaw();
    if( questionText == "BOOL"){
        if( index == 0 ){
            return 'yes';
        }
        if( index == 1 ){
            return 'no';
        }
        return null;
    }
    if( label[index] ){
        return label[index].answerText;
    }
    return null;
});

// show if questionText is A
Facade.Components.Field.forName("checkboxSet").setMask(function(behaviorFn, args) {
    var questionText = this.getPathData().get('questionType');
    if (questionText == "SELECT") {
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

Facade.Components.Radio.forKind('answerCheckbox').setMask(function(behaviorFn,args){
    var opts = this.getPathData().get('answerOptions').getRaw();
    var questionText = this.getPathData().get('questionType');
    var index = this.getItemSelectionName();

    if( opts[index] ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;

});
Facade.FunctionRegistry.register("page.checkbox.setLabel",function(behaviorFn,args){
    var label = this.getPathData().get('answerOptions').getRaw();
    var questionText = this.getPathData().get('questionType');
    var index = this.getItemSelectionName();
    if( label[index] ){
        return label[index].answerText;
    }
    return null;
});
Facade.FunctionRegistry.register("page.fib.setMask",function(behaviorFn,args){
    var questionType = this.getPathData().getParentPathData().get('questionType');
    if (questionType === "FIB") {
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});
Facade.FunctionRegistry.register("page.open.setMask",function(behaviorFn,args){
    var questionType = this.getPathData().getParentPathData().get('questionType');
    if (questionType === "OPEN") {
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

var myBtnBar = Facade.Components.Docbar.forKind("SurveyReview").buttonbar()
myBtnBar.setButtons(["back","finish"]);
myBtnBar.button('back').navigateToPage("SurveyIncomplete");
myBtnBar.button('back').setLabel("Edit Survey");
myBtnBar.button('finish').setLabel("Submit Survey");
myBtnBar.button('finish').setOnClick( function() {
    Facade.PageRegistry.transition("wf_finalize").then( function(){
        Facade.PageRegistry.setCurrent("SurveyIncomplete");
    });
});

Facade.FunctionRegistry.register('getFieldHeight',function(){
    var questionType = this.getPathData().getParentPathData().get('questionType');
    if( questionType == "OPEN"){
        return 5;
    }
    return 1;
});

Facade.FunctionRegistry.register("page.responseText.setMask",function(behaviorFn,args){
    var questionType = this.getPathData().getParentPathData().get('questionType');
    if( (questionType == "FIB" || questionType == "OPEN")  ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

Facade.FunctionRegistry.register('orderedListFn', function(){
    if( this.getPathData().getParentPathData().get('order') ){
        return this.getPathData().getParentPathData().get('order') + ". ";
    }
})

Facade.Behaviors.Page.forPage('SurveyReview').onLoad( function(){
    var questions = Facade.PageRegistry.getPrimaryData().get('questionList');
    var raw = questions && questions.getRaw();
    for( var i = 0; i < raw && raw.length; i++){
        raw[i].order = i + 1;
    }
});