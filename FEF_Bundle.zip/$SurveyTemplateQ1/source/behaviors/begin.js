
Facade.Behaviors.App.preLoad( function(behaviorFn, args){
});

Facade.Behaviors.Page.forPage("SurveyIncomplete").onLoad( function(behaviorFn,args){
    var design = Facade.DesignRegistry.get( Facade.PageRegistry.getPrimaryData().get('type') );
    design.addField('clientAnswerList').setFunctionalType( Facade.Constants.FunctionalType.TEXT );

    var questionList = Facade.PageRegistry.getPrimaryData().get('questionList') &&
        Facade.PageRegistry.getPrimaryData().get('questionList').getRaw();
    if(questionList){
        //Here we are taking each embedded answer option, and putting the list of embedded objects
        // into one string to display nicely on our UI
        for( var i = 0 ; i < questionList.length ; i++ ){
            var temp = "";
            var answers = questionList[i].answerOptions;
            for( var j = 0; j < answers.length ; j++){
                temp += answers[j].answerText + "\n";
            }
            questionList[i].clientAnswerList = temp;
        }
    }

});
var appStarting = false;
Facade.Behaviors.Page.onLoad( function(behaviorFn,args){
    appStarting = true;
    if(  ! Facade.PageRegistry.getPrimaryData().isNew() ){
        return Facade.PageRegistry.save();
    }
});

Facade.FunctionRegistry.register("core.page.onSaveSuccess", function (behaviorFn, args) {
    console.log('saveSucc');
    if (appStarting) {
        appStarting = false;
    }
    else {
        behaviorFn.resume();
    }
});

var docBarButtonbar = Facade.Components.Docbar.buttonbar();
docBarButtonbar.appendButtons(["review"]);
var btn = docBarButtonbar.button('review');
btn.navigateToPage("SurveyReview");
btn.setLabel("Preview Survey");
btn.setEnabled( function(){
    return ( ! Facade.PageRegistry.inEditMode() );
});
docBarButtonbar.button('wf_finalize').setMask( Facade.Constants.Mask.HIDDEN );
docBarButtonbar.button('edit').setMask( function(){
    var data = Facade.PageRegistry.getPrimaryData();
    if( data.get('state') == 'incomplete' &&
        ( ! Facade.PageRegistry.inEditMode() ) ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
})
docBarButtonbar.button('save').setMask( function(){
    var data = Facade.PageRegistry.getPrimaryData();
    if( data.get('state') == 'incomplete'){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
})
docBarButtonbar.button('wf_reopen').setOnClick( function(){
    Facade.PageRegistry.transition('wf_reopen').then( function(){
        var questionList = Facade.PageRegistry.getPrimaryData().get('questionList').getRaw();
        for( var i = 0 ; i < questionList.length ; i++ ){
            var temp = "";
            var answers = questionList[i].answerOptions;
            for( var j = 0; j < answers.length ; j++){
                temp += answers[j].answerText + "\n";
            }
            questionList[i].clientAnswerList = temp;
        }
        Facade.PageRegistry.save();
    });
})


var tableContainer = Facade.Components.Table.forName("surveyQuestions");
tableContainer.itemAddButton().setMask(Facade.Constants.Mask.HIDDEN);
tableContainer.row().checkboxSelection().setMask( function(){
    return Facade.PageRegistry.inEditMode() ? Facade.Constants.Mask.NORMAL : Facade.Constants.Mask.HIDDEN;
});
tableContainer.field('clientAnswerList').setEditMode( false );

var onChangePopover = Facade.Components.Popover.forName("questionType.onChange.pop");
onChangePopover.setPopoverHeight( "200px" );

var btnBar = onChangePopover.buttonbar();
btnBar.setButtons(["revert", "continue"]);
btnBar.button("revert").setLabel("Revert").setOnClick( function(behaviorFn,args){
    var current_popup = behaviorFn.components.popover.hide();
});
btnBar.button("continue").setLabel("Continue").setOnClick( function(behaviorFn,args){
    var current_popup = behaviorFn.components.popover.hide();
});


var answer_option_counter = 1;
var selectedQuestionRow;

Facade.Components.Button.forName("popoverAddBtn").setOnClick(function(behaviorFn,args){
    answer_option_counter++;
});

Facade.Components.Button.forName("addAnotherQuestion").setOnClick(function(behaviorFn,args){
    Facade.PageRegistry.getComponent("surveyQuestions").addItem();
});

Facade.Components.Button.forName("addAnswerOptions").setOnClick( function(behaviorFn,args){
    var pop = Facade.PageRegistry.getComponent("answerOptionPopover");

    selectedQuestionRow = parseInt(behaviorFn.components.tableRow._name);

    //Set up popover for individual question
    Facade.FunctionRegistry.execute("popover.init.tempData", { row_index: selectedQuestionRow });

    pop.show();
}).setEnabled( function(behaviorFn, args){
    var questionType = this.getPathData().get('questionType');
    if( questionType == "CHOICE" ||
        questionType == "SELECT"){
        return true;
    }
    return false;
});

var storeClientAnswerLists = [];
Facade.Components.Docbar.buttonbar().button("save").setOnClick( function( behaviorFn, args){
    storeClientAnswerLists = [];
    var questions = Facade.PageRegistry.getPrimaryData().get('questionList') &&
                    Facade.PageRegistry.getPrimaryData().get('questionList').getRaw();
    if( questions ){
        for( var i = 0; i < questions.length; i++ ){
            storeClientAnswerLists.push( questions[i].clientAnswerList );
        }

        var primaryDataQuestions = Facade.PageRegistry.getPrimaryData().get('questionList').getRaw();

        Facade.FunctionRegistry.execute('save.answerList');

        Facade.PageRegistry.save().then( function(){
            console.log('postSave');
            var questions = Facade.PageRegistry.getPrimaryData().get('questionList').getRaw();
            for( var i = 0; i < storeClientAnswerLists.length; i++ ){
                questions[i].clientAnswerList = storeClientAnswerLists[i];
            }
            Facade.PageRegistry.save();
        });
    }
    else{
        Facade.PageRegistry.save();
    }


});

Facade.FunctionRegistry.register("save.answerList", function(){
    console.log('saveanswerlist');
    var primaryDataQuestions = Facade.PageRegistry.getPrimaryData().get('questionList').getRaw();
    for( var i = 0; i < primaryDataQuestions.length; i++ ){
        var answers = [];
        var myQuestion = primaryDataQuestions[i];
        var current_answers = myQuestion.clientAnswerList.split("\n");
        for( var k = 0; k < current_answers.length; k++ ){
            if( current_answers[k] != "" ){
                answers.push( {"answerText" : current_answers[k]} );
            }
        }
        primaryDataQuestions[i].answerOptions = answers;

    }

});

Facade.FunctionRegistry.register("popover.init.tempData", function(behaviorFn,args){
    var myQuestion = Facade.PageRegistry.getPrimaryData().get('questionList').get( args.row_index );
    var answerField = myQuestion.get('clientAnswerList');
    Facade.PageRegistry.getPrimaryData().set("temp", {} );
    var tempObj = Facade.PageRegistry.getPrimaryData().data.temp;
    var answers;

    if( answerField) {
        answers = answerField.split("\n");

        for(var i=0 ; i < answers.length; i++){
            tempObj["field" + i] = answers[i];
        }
    }

    answer_option_counter = answers ? answers.length : 1;
});


Facade.Components.Button.forName("addAnswerOptions").setMask( function(behaviorFn,args){
    if( Facade.PageRegistry.inEditMode()){
        return Facade.Constants.Mask.NORMAL;
    }
    else{
        return Facade.Constants.Mask.HIDDEN;
    }
});


//Facade.FunctionRegistry.register("#surveyQuestions.#questionType.onChange", function(behaviorFn, args){
Facade.FunctionRegistry.register("question.questiontype.onChange", function(behaviorFn, args){
    var row = behaviorFn.components.tableRow._name;
    var parse = parseInt(row);
    var data = Facade.DataRegistry.get("core.page.data.primary");
    var rowData = data.data.questionList[parse];
    console.log(rowData.questionType);

    var answerList = rowData.clientAnswerList;
    //If true, then answerList contains answers -
    //prompt user before deleting them

    /*
    if( answerList != "" &&
        answerList != "Short text" &&
        answerList != "yes or no" &&
        answerList != "Text section"){
        var pop = Facade.PageRegistry.getComponent('questionType.onChange.pop');
        pop.show();
        return;
    }
    */

    switch( rowData.questionType){
        case "FIB":
            rowData.clientAnswerList = "Short text";
            break;
        case "OPEN":
            rowData.clientAnswerList = "Text section";
            break;
        case "BOOL":
            rowData.clientAnswerList = "yes or no";
            break;
        //case "CHOICE":
        //case "SELECT":
            //console.log('choice/select');
            //break;
        default:
            rowData.clientAnswerList = "";
            break;
    }
});



Facade.FunctionRegistry.register("#answerOptionPopover.onClose", function(behaviorFn,args){
    var primaryData = Facade.PageRegistry.getPrimaryData().data;
    var popoverData = primaryData.temp;
    var all_answers = "";
    _.each(popoverData, function(val, key ){
        if( val != "" ){
            all_answers+= val.trim() + "\n";
        }
    });
    primaryData.questionList[ selectedQuestionRow ].clientAnswerList= all_answers;

    this.hide();
});
//Only show textboxes that are filled with answer options. Hide the rest
Facade.FunctionRegistry.register("setPopoverTextEditMode",function(behaviorFn,args){
    var fieldName = this.getName();
    var index = fieldName.charAt(fieldName.length-1);
    if(answer_option_counter > index){
        return true;
    }
    else{
        return false;
    }
});