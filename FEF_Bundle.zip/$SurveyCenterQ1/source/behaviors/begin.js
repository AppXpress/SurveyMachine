var popoverTextMessage;

//No need to save anything here, so clear save strategy
Facade.Behaviors.App.saveStrategy().candidates().forType("");

Facade.Behaviors.App.preLoad( function() {
    return Facade.Resolver.query("$SurveyTemplateQ1", {
        params: {oql: "1=1"},
        alias: "SurveyList"
    }).then(function(results){
        Facade.PicklistRegistry.register("SurveyList",new Facade.Prototypes.Picklist(results,{
            getLabel: function(item){ return item.getRaw('title')},
            getValue: function(item){ return item.getRaw('uid')} }) );
    })
});
Facade.Behaviors.App.preLoad( function() {
    var projectDesign = Facade.DesignRegistry.register(new Facade.Prototypes.Design(undefined,{designType: "PartyPlace"}))
    projectDesign.addField("myPartyField").setFunctionalType(Facade.Constants.FunctionalType.PARTY);

    var partyData = new Facade.Prototypes.Data(undefined, { type: "PartyPlace"} );
    Facade.DataRegistry.register("party", partyData);

    var data = Facade.DataRegistry.register("orgAssignList",new Facade.Prototypes.DataList([], undefined ));
});

Facade.Components.Docbar.buttonbar().setMask( Facade.Constants.Mask.HIDDEN );


Facade.FunctionRegistry.register("#surveyDropdown.onSelect",function(behaviorFn,args){
    var dropdown1 = Facade.PageRegistry.getComponent("surveyDropdown")
    var dropdownSelection = dropdown1 && dropdown1.getSelectedKey();

    var thisSurvey = Facade.PageRegistry.getPrimaryData();
    thisSurvey.set("surveyID", new Facade.Prototypes.Data( { data: dropdownSelection }));


    if( dropdownSelection == '-1' || dropdownSelection == '' ||
        ( ! dropdownSelection) ){
        Facade.DataRegistry.get('party').set('myPartyField', undefined);
    }
});

Facade.FunctionRegistry.register("getSurveyTitleAssign",function(){
    var selectedSurvey = Facade.PageRegistry.getComponent("surveyDropdown").getSelectedItem();
    if( selectedSurvey ){
        return selectedSurvey.get('title');
    }
    else{
        Facade.DataRegistry.register('orgAssignList', new Facade.Prototypes.DataList([], undefined));
    }

});

Facade.FunctionRegistry.register("getSurveyTitleResults",function(){
    var selectedSurvey = Facade.PageRegistry.getComponent("surveyDropdown2").getSelectedItem();
    if( selectedSurvey ){
        return selectedSurvey.get('title');
    }
    else{
        //Facade.DataRegistry.register('getResults', new Facade.Prototypes.Data(undefined));
    }
});
Facade.Components.Lookup.forName('myPartyLookup').setEditMode( function(){
    var selectedSurvey = Facade.PageRegistry.getComponent("surveyDropdown").getSelectedItem();
    return selectedSurvey ? true : false;
})

Facade.Components.Button.forName('assignSurveyButton').setEnabled(function(){
    var assignListLength = Facade.DataRegistry.get('orgAssignList').getResults().length;
    return assignListLength > 0 ? true : false ;
});



Facade.FunctionRegistry.register('getOrgInfo',function(){
    var data = this.getPathData().get('name');
    return data;
});

Facade.FunctionRegistry.register('#myPartyLookup.onChange',function(behaviorFn,args){
    var selectedParty = this.getPathData();
    var id = selectedParty.get('memberId');
    var name = selectedParty.get('name');
    var freshData = new Facade.Prototypes.Data({ memberId: id , name: name});
    Facade.DataRegistry.get('orgAssignList').pushResult( freshData );
});

Facade.Components.Button.forName('assignSurveyButton').setOnClick(function(behaviorFn,args){
    var selectedSurvey = Facade.PageRegistry.getComponent('surveyDropdown');
    var surveyID = selectedSurvey.getSelectedKey();
    var name = selectedSurvey.getSelectedItem().get('title');
    var assignList = Facade.DataRegistry.get('orgAssignList').getResults();
    var surveys = Facade.DataRegistry.get('SurveyList');
    for( var i = 0 ; i < assignList.length; i++ ){
        var assignOrg = {
            "memberId" : assignList[i].get('memberId')
        }
        var payload = {
            "name": name ,
            "surveyID" : surveyID ,
            "assignee" : assignOrg ,
            "type": "$SurveyQ1"
        }
        var list;
        for( var j = 0 ; j < surveys.getLength() ; j++ ){
            if( surveyID == surveys.get(j).get('uid')){
                list = surveys.get(j).get('questionList');
            }
        }
        if( list ){
            list = list.getRaw();
            for( var k = 0 ; k < list.length ; k++){
                var question = list[k];
                question.questionID = question.uid;
            }
        }
        payload.responseList = list;


        if( i == (assignList.length - 1 )){

            Facade.API.flush("$SurveyQ1", null , new Facade.Prototypes.Data( payload ))
                .then( function(){
                    Facade.PageRegistry.alert("Successfully assigned surveys!")
                    Facade.DataRegistry.get('party').set('myPartyField', undefined);
                    Facade.DataRegistry.register('orgAssignList', new Facade.Prototypes.DataList([], undefined));
                } , function(){
                    Facade.PageRegistry.alert("Error assigning surveys. Check connection or contact GTNexus")
                })


            break;
        }
        //Create new survey
        Facade.API.flush("$SurveyQ1", null , new Facade.Prototypes.Data( payload ) )

        //ON last survey created, make sure success then show user popup
    }

});
Facade.FunctionRegistry.register("getPopoverMessage", function(){
    return popoverTextMessage;
});

Facade.FunctionRegistry.register('removePath',function(){
    var idToRemove = this.getPathData().get('memberId');
    var nameToRemove = this.getPathData().get('name');
    var orgsList = Facade.DataRegistry.get('orgAssignList');
    for( var i = 0; i < orgsList.getLength(); i++ ){
        if( idToRemove == orgsList.get(i).get('memberId') &&
            nameToRemove == orgsList.get(i).get('name') ){
            orgsList.removeResult(i);
            break;
        }
    }
});

Facade.FunctionRegistry.register('orgSelected',function(){
    if( Facade.DataRegistry.get('orgAssignList').getLength() > 0 ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
})
/*
Facade.FunctionRegistry.register('create.surveys', function(behaviorFn,args){

});
*/

//Results Tab
/////////////////////////////////////////////////////////////////////////////////////////
//Facade.Components.Table.field('dateCompleted').setData( function(behaviorFn,args){
//    console.log('setting myfield data')
//    return "myData";
//});

Facade.FunctionRegistry.register("table.results.mask",function(){
    var dropdown1 = Facade.PageRegistry.getComponent("surveyDropdown2");
    return dropdown1.getSelectedKey() ? Facade.Constants.Mask.NORMAL : Facade.Constants.Mask.HIDDEN;
});

Facade.FunctionRegistry.register('#surveyDropdown2.onSelect', function(behaviorFn,args){
    var selectedSurvey = this.getSelectedItem();
    Facade.DataRegistry.evict('getResults');
    if( selectedSurvey ){
        var surveyID = this.getSelectedItem().get('uid');
        var oqlStatement = "surveyID = " + surveyID + "";
        //Query for all surveys with that ID
        return Facade.Resolver.query("$SurveyQ1", {
            params: {oql: oqlStatement},
            slotName: "getResults"
        });
    }
    else{
        //Facade.DataRegistry.register('getResults', new Facade.Prototypes.Data(undefined));
    }


});

var surveyLink = Facade.Components.Link.forKind("surveyLink");
//surveyLink.setLabel('Go To Survey');
surveyLink.setLink( function(){
    var surveyUid = this.getPathData().getParentPathData().get('uid');
    var globalType = this.getPathData().getParentPathData().get('type');
    return new Facade.Prototypes.Link(globalType + "?key=" + surveyUid).setLabel('Go To Survey');
});


