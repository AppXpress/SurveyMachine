/**
 * Created by areynolds on 8/12/2015.
 */
var inSubmitMode = false;

//Load questions
Facade.Behaviors.App.onLoad(function(){
    var data = Facade.PageRegistry.getPrimaryData();
    var myQuestions = data.get('responseList');
    for( var i = 0; i < myQuestions.getLength(); i++){
        var question = myQuestions.get(i).getRaw();
        question.order = i + 1;
    }
    if( data.get('state') == 'completed'){
        inSubmitMode = true;
    }
    data.resetClean();
});

Facade.FunctionRegistry.register('orderedListFn', function(){
    if( this.getPathData().getParentPathData().get('order') ){
        return this.getPathData().getParentPathData().get('order') + ". ";
    }
})
Facade.FunctionRegistry.register('radiobtnClickFn',function(behaviorFn,args){
    var thisQuestion = this.getPathData().getRaw();
    thisQuestion.responseText = this.getLabel();
    return behaviorFn.resume();
})


Facade.Components.Button.forName('submit').setMask( function(){
    if( inSubmitMode ){
        return Facade.Constants.Mask.HIDDEN;
    }
    return Facade.Constants.Mask.NORMAL;
})


Facade.Components.Button.forName('submit').setOnClick( function() {

    //Validate that survey is complete
    var unAnsweredQuestions;
    var questionList = Facade.PageRegistry.getPrimaryData().get('responseList');
    for( var i = 0; i < questionList.getLength(); i++ ){
        var answer = questionList.get(i).get('responseText');
        if( ! answer ){
            if( ! unAnsweredQuestions ){
                unAnsweredQuestions = questionList.get(i).get('order') + ",";
            }
            else{
                unAnsweredQuestions += questionList.get(i).get('order') + ",";
            }
        }
    }
    if( unAnsweredQuestions ){
        unAnsweredQuestions = unAnsweredQuestions.slice(0,-1);
        Facade.PageRegistry.alert("Cannot submit survey. You have not answered the following questions: \n " + unAnsweredQuestions );
        return;
    }

    Facade.PageRegistry.save().then( function(){
        Facade.PageRegistry.transition("wf_submit").then( function(){
            Facade.PageRegistry.alert("Your survey has been submitted. Thank you! ");
            inSubmitMode = true;
        });
    })
});

/////////////////////////////////////////////////////////////////////////////////////

// show if questionText is A
Facade.Components.Field.forName("radioSetField").setMask(function(behaviorFn, args) {

    var questionText = this.getPathData().get('questionType');
    if ( (questionText === "BOOL" || questionText == "CHOICE") && ( ! inSubmitMode ) ){//||//questionText == "SELECT") {
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;

});

Facade.Components.Radio.forKind('radiobtn').setMask(function(behaviorFn,args){

    var field = this.getPathData();
    var opts = field.get('answerOptions').getRaw();
    var questionText = field.get('questionType');
    var index = this.getValue().getRaw();
    if(questionText == 'BOOL'){
        if( index < 2 ){
            return Facade.Constants.Mask.NORMAL;
        }
    }

    if( opts[index] && ( ! inSubmitMode )){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;

});

//Facade.Components.Radio.forKind('radiobtn').setChecked( function(behaviorFn, args) {
//    return behaviorFn.resume();
//});

Facade.FunctionRegistry.register("page.radiobtn.setLabel",function(behaviorFn,args){
    var field = this.getPathData();
    var label = field.get('answerOptions').getRaw();
    var questionText = field.get('questionType');
    var index = this.getValue().getRaw();
    if( questionText == "BOOL"){
        if( index == 0 ){
            return 'yes';
        }
        if( index == 1 ){
            return 'no';
        }
        return null;
    }
    if( label[index] ){
        return label[index].answerText;
    }
    return null;
});

// show if questionText is A
Facade.Components.Field.forName("checkboxSet").setMask(function(behaviorFn, args) {

    var questionText = this.getPathData().get('questionType');
    if (questionText == "SELECT" && (! inSubmitMode )) {
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

Facade.Components.Radio.forKind('answerCheckbox').setMask(function(behaviorFn,args){
    var field = this.getPathData();
    var opts = field.get('answerOptions').getRaw();
    var index = this.getItemSelectionName();

    if( opts[index] ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

Facade.Components.Checkbox.forKind('answerCheckbox').setOnClick( function(behaviorFn,args){
    console.log('checked' + this.getChecked() );
    var field = this.getPathData();
    var label = field.get('answerOptions').getRaw();
    var index = this.getItemSelectionName();

    //Have answer to add
    var answerToAdd = label[index].answerText;

    //Add answer
    if( ! this.getChecked() ) {

        var thisQuestion = field.get('uid');
        var mySurvey = Facade.PageRegistry.getPrimaryData().get('responseList');
        for (var i = 0; i < mySurvey.getLength(); i++) {
            if (mySurvey.get(i).getRaw().questionID == thisQuestion) {
                if( mySurvey.getRaw()[i].responseText ){
                    mySurvey.getRaw()[i].responseText = mySurvey.getRaw()[i].responseText + "|&|" + answerToAdd;
                }
                else{
                    mySurvey.getRaw()[i].responseText = answerToAdd;
                }

            }
        }
    }
    //Remove answerToAdd
    else{
        var thisQuestion = field.get('uid');
        var mySurvey = Facade.PageRegistry.getPrimaryData().get('responseList');
        for (var i = 0; i < mySurvey.getLength(); i++) {
            if (mySurvey.get(i).getRaw().questionID == thisQuestion) {
                var str = mySurvey.getRaw()[i].responseText;
                if( str.indexOf('|&|') > -1 ){
                    answerToAdd = "|&|" + answerToAdd;
                }

                if( str.indexOf(answerToAdd) > -1 ){
                    str = str.replace(answerToAdd, "");
                }
                mySurvey.getRaw()[i].responseText = str;
            }
        }
    }

    console.log('clicker');
    return behaviorFn.resume();
});

Facade.FunctionRegistry.register("page.checkbox.setLabel",function(behaviorFn,args){
    var field = this.getPathData();
    if( ! field.get('answerOptions') ){ return; }
    var label = field.get('answerOptions').getRaw();
    var questionText = this.getPathData().getParentPathData().get('questionType');
    var index = this.getItemSelectionName();
    if( label[index] ){
        return label[index].answerText;
    }
    return null;
});
Facade.FunctionRegistry.register("page.responseText.setMask",function(behaviorFn,args){
    var questionType = this.getPathData().getParentPathData().get('questionType');
    if( (questionType == "FIB" || questionType == "OPEN") && ( ! inSubmitMode ) ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

Facade.FunctionRegistry.register('getSubmittedAnswerText',function(behaviorFn,args){
    var answer = this.getPathData().get('responseText');
    if( answer ){
        while( answer.indexOf('|&|') > -1 ){
            answer = answer.replace('|&|',',');
        }
    }
    return answer;
});

Facade.FunctionRegistry.register('inSubmitMode', function(){
    if( inSubmitMode ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

Facade.FunctionRegistry.register('notInSubmitMode', function(){
    if( ! inSubmitMode ){
        return Facade.Constants.Mask.NORMAL;
    }
    return Facade.Constants.Mask.HIDDEN;
});

Facade.FunctionRegistry.register('getFieldHeight',function(){
    var questionType = this.getPathData().getParentPathData().get('questionType');
    if( questionType == "OPEN"){
        return 5;
    }
    return 1;
});

Facade.Behaviors.Page.preDestroy(function(behaviorFn,args){
    if( inSubmitMode ){
        var data = Facade.PageRegistry.getPrimaryData();
        data.resetClean();

    }
});


Facade.Behaviors.App.preLoad( function(){
    var design = Facade.DesignRegistry.register(new Facade.Prototypes.Design(undefined,{designType: "PopoverFields"}));
    design.addField('random').setFunctionalType(Facade.Constants.FunctionalType.TEXT);
    var projectList = Facade.DataRegistry.register("testData",new Facade.Prototypes.DataList([],{type: "PopoverFields"}));
    projectList.pushResult( new Facade.Prototypes.Data({ random : 'exon'}));
    projectList.pushResult( new Facade.Prototypes.Data({}));
});



Facade.Components.Button.forName('testButton').setOnClick(function(){
    var pop = Facade.PageRegistry.getComponent('tester').show();
});

Facade.FunctionRegistry.register('add',function(){
    var data = Facade.DataRegistry.get('testData');
    data.pushResult( new Facade.Prototypes.Data( {} ) );
});