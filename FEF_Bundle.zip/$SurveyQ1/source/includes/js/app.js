/**
 * Created by areynolds on 8/24/2015.
 */

(function($){
    $('input').prop('disabled', true );
}(jQuery));