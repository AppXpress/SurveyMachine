function fnOnStart(myObject, eventName, params){
	var thisDate = new Date();
	myObject.dateCreated = thisDate;
	
	Providers.getPersistenceProvider().save(myObject);
}