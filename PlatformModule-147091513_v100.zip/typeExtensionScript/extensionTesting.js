function onSave(obj){
	//obj.currencyCode = "USD";
	Providers.getPersistenceProvider().save(obj);
}

function onValidate(){
	Providers.getMessageProvider().error().msgKey("This runs").build();
}

function onActivate(){
}

function onCancel(){
}

function onClose(){
}