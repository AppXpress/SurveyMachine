function fnOnStart(myObject, eventName, params){
	var thisDate = new Date();
	myObject.dateAssigned = thisDate;
	
	Providers.getPersistenceProvider().save(myObject);
}

function fnOnComplete(myObject, eventName, params){
	var thisDate = new Date();
	myObject.dateCompleted = thisDate;
	
	Providers.getPersistenceProvider().save(myObject);
}

function fnOnReopen(myObject, eventName, params){
	myObject.dateCompleted = undefined;
	var responses = myObject.responseList;
	for( i = 0; i < responses.length; i++){
		responses[i].responseText = undefined;
	}
	myObject.responseList = responses;
	Providers.getPersistenceProvider().save(myObject);

}